import numpy as np
import matplotlib.pyplot as plt
pos, x, dx, v, dv = np.loadtxt("Run1Trial12.csv", skiprows=1, unpack=True, delimiter=',')
##pos, x, dx, v, dv = np.loadtxt("Run1Trial1.csv", skiprows=0, unpack=True, delimiter=',')
plt.errorbar(v, x, fmt ='ro', label ='Uncertainities', yerr= dx, xerr=dv, ecolor='grey')

x1 = v[0] - dv[0]
y1 = x[0] - dx[0]
x2 = v[5] - dv[5]
y2 = x[5] + dx[5]

a1 = v[0] + dv[0]
b1 = x[0] + dx[0]
a2 = v[5] + dv[5]
b2 = x[5] - dx[5]

(m,b) = np.polyfit(v,x,1)
equation = 'Best Fit: x = ' + str(round(m,3)) + 'v'
plt.plot(v,np.polyval((m,b),v), color = 'black', 
        label = equation, linestyle = 'solid', zorder = -1)
print (equation)

p =[x1,x2]
q =[y1,y2]
plt.plot(p,q, '-b', label = 'Max Fit: x = ' + str(round(y2/x2,3)) + 'v')

r =[a1,a2]
s =[b1,b2]
plt.plot(r,s, '-r', label =  'Min Fit: x = ' + str(round(b2/a2,3)) + 'v' )

#point = "(" + str(x1) + "," + str(y1) + ")"
#print(point)
#point = "(" + str(x2) + "," + str(y2) + ")"
#print(point)

plt.xlabel('v [m/s]')
plt.ylabel('x [m]')
plt.legend(loc='best')
plt.axhline(color='gray',zorder=-1)
plt.axvline(color='gray',zorder=-1)
plt.title('PHY 133 Lab 3 - Projectile Motion - x vs v')
plt.show()
